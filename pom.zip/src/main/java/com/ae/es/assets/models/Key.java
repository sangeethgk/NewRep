package com.ae.es.assets.models;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class Key {

	@NotBlank(message = "Key shouldn't be blank!")
	@Size(min = 5, max = 20, message = "Key should be between 5 to 20 bits in length")
	private String keyValue;

	public String getKeyValue() {
		return keyValue;
	}

	public void setKeyValue(String keyValue) {
		this.keyValue = keyValue;
	}

	public Key(String keyValue) {
		super();
		this.keyValue = keyValue;
	}

	protected Key() {

	}
}
