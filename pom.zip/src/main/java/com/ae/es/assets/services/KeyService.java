package com.ae.es.assets.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
//import com.ae.es.assets.models.Feedback;
import com.ae.es.assets.models.Key;

@Service
public class KeyService {

	public List<Key> getAllKeys() throws Exception {

		List<Key> keyList = new ArrayList<>();

		keyList.add(new Key("key1"));
		keyList.add(new Key("key2"));
		keyList.add(new Key("key3"));

		return keyList;
	}

	public Key shipKey(Key key) throws Exception {

		String inputKey = key.getKeyValue();
		// Raise exception if input is null
//		if (inputKey.isEmpty() || inputKey.trim().length() == 0) {
//			throw new EmptyInputException("601", "No input supplied!");
//		}
		String encryptedKey = "";
		// Encrypt input key
		AesEncryptionService aes_encryption = new AesEncryptionService();

		aes_encryption.init();
		encryptedKey = aes_encryption.encrypt(inputKey);

		// String decryptedKey = aes_encryption.decrypt(encryptedData);

		// Set encrypted key
		key.setKeyValue(encryptedKey);

		// Call cloud API here.

		return key;
	}

}
