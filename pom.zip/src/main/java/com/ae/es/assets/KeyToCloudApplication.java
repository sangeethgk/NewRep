package com.ae.es.assets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//import com.ae.es.assets.services.AesEncryptionService;

@SpringBootApplication
public class KeyToCloudApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(KeyToCloudApplication.class, args);
		//System.out.println(System.getProperty("java.io.tmpdir"));
	}

}
