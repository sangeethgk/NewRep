package com.ae.es.assets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

//import com.ae.es.assets.services.AesEncryptionService;

@SpringBootApplication
public class KeyToCloudApplication extends SpringBootServletInitializer{
	
	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(KeyToCloudApplication.class);
    }

	public static void main(String[] args) throws Exception {
		SpringApplication.run(KeyToCloudApplication.class, args);
		//System.out.println(System.getProperty("java.io.tmpdir"));
	}

}
