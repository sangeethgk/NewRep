package com.ae.es.assets.models;

public class Feedback {
	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Feedback(String message) {
		super();
		this.message = message;
	}

}
