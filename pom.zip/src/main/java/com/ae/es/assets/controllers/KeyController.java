package com.ae.es.assets.controllers;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

//import com.ae.es.assets.models.Feedback;
import com.ae.es.assets.models.Key;
import com.ae.es.assets.services.KeyService;

@RestController
@Validated
public class KeyController {

	private static final Logger log = LoggerFactory.getLogger(KeyController.class);

	@Autowired
	private KeyService keyService;

	@GetMapping("/keys")
	public List<Key> getAllKeys() throws Exception {
		return keyService.getAllKeys();
	}

	@PostMapping("/shipkey")
	public ResponseEntity<Key> shipKey(@Valid @RequestBody Key key) throws Exception {
		log.info("Key Shipped!");
		//return keyService.shipKey(key);
		return new ResponseEntity<Key>(keyService.shipKey(key), HttpStatus.CREATED);
	}

}
