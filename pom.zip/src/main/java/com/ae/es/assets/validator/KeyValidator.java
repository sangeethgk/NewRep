package com.ae.es.assets.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.ae.es.assets.models.Key;

public class KeyValidator implements ConstraintValidator<ValidKeyObject, Key> {

	@Override
	public void initialize(ValidKeyObject constraintAnnotation) {

	}

	@Override
	public boolean isValid(Key value, ConstraintValidatorContext context) {
		String keyValue = value.getKeyValue();
		if (keyValue == null)
			return false;
		return keyValue.length() >= 5 && keyValue.length() <= 20;
	}

}
