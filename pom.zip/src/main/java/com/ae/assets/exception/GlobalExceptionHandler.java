package com.ae.assets.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ae.es.assets.controllers.KeyController;
import com.ae.es.dto.ErrorDTO;

@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class GlobalExceptionHandler{

	private static final Logger log = LoggerFactory.getLogger(KeyController.class);
	// handle specific exceptions
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ResponseEntity<ErrorDTO> handleEmptyInputException(final MethodArgumentNotValidException exception) {
		log.info("MethodArgumentNotValidException!");
		return new ResponseEntity<ErrorDTO>(ErrorDTO.builder()
				.withTitle("Invalid input!")
				.withDetail(exception.getMessage())
				.withStatus(HttpStatus.BAD_REQUEST.value())
				.withErrorType(MethodArgumentNotValidException.class.getSimpleName())
				.withErrorCode("K001")
				.build(), 
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ResponseEntity<ErrorDTO> handleOtherException(final Exception exception) {
		log.info("Exception!");
		return new ResponseEntity<ErrorDTO>(ErrorDTO.builder()
				.withDetail(exception.getMessage())
				.withStatus(HttpStatus.BAD_REQUEST.value())
				.withErrorType(MethodArgumentNotValidException.class.getSimpleName())
				.withErrorCode("G001")
				.build(), 
				HttpStatus.BAD_REQUEST);
	}

	
}
