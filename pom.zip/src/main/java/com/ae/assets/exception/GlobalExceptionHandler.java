package com.ae.assets.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.ae.es.dto.ErrorDTO;

@ControllerAdvice
public class GlobalExceptionHandler {

	// handle specific exceptions
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorDTO> handleEmptyInputException(final EmptyInputException exception) {
		return new ResponseEntity<ErrorDTO>(ErrorDTO.builder()
				.withTitle("Invalid input!")
				.withDetail(exception.getMessage())
				.withStatus(HttpStatus.BAD_REQUEST.value())
				.withErrorType(MethodArgumentNotValidException.class.getSimpleName())
				.withErrorCode("K001")
				.build(), 
				HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorDTO> handleOtherException(final Exception exception) {
		return new ResponseEntity<ErrorDTO>(ErrorDTO.builder()
				.withDetail(exception.getMessage())
				.withStatus(HttpStatus.BAD_REQUEST.value())
				.withErrorType(MethodArgumentNotValidException.class.getSimpleName())
				.withErrorCode("G001")
				.build(), 
				HttpStatus.BAD_REQUEST);
	}

	
}
